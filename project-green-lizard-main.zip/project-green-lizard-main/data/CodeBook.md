# Codebook: Premier League Performance Analysis

## Dataset Overview

This codebook describes the three datasets used in our Premier League performance analysis. The project combines data from **FBref** and **Transfermarkt** to examine how team performance is related to financial investment, squad characteristics, and disciplinary behavior.

-   **Time period:** 2019–2025
-   **Main outcome:** Premier League ranking and points
-   **Main predictors:** transfer spending, squad value, average age, yellow cards, and red cards

------------------------------------------------------------------------

## Dataset 1: `team_season_data.csv`

### Description

This dataset contains team-level performance, financial, and squad information for each Premier League season.

### Unit of Observation

Each row represents one **team-season**.

### Variables

| Variable | Type | Description | Units / Notes |
|----------------|----------------|-------------------|----------------------|
| `Rk` | numeric | Final league ranking | Lower = better |
| `Squad` | character | Team name | Standardized across datasets |
| `MP` | numeric | Matches played | Games |
| `W` | numeric | Wins | Count |
| `D` | numeric | Draws | Count |
| `L` | numeric | Losses | Count |
| `GF` | numeric | Goals scored | Goals |
| `GA` | numeric | Goals conceded | Goals |
| `GD` | numeric | Goal difference | `GF - GA` |
| `Pts` | numeric | Total league points | Points |
| `Season` | numeric / character | Season identifier | Example: 2019, 2020 |
| `spend_usd` | numeric | Transfer spending | USD |
| `income_usd` | numeric | Transfer income | USD |
| `net_spend_usd` | numeric | Net transfer spending | Spending minus income |
| `squad_value_eur` | numeric | Estimated squad market value | EUR |
| `avg_age` | numeric | Average squad age | Years |

------------------------------------------------------------------------

## Dataset 2: `player_season_data.csv`

### Description

This dataset contains player-level or player-position disciplinary information by team and season.

### Unit of Observation

Each row represents a **player or player-position-season record**.

### Variables

| Variable | Type | Description | Units / Notes |
|----------------|----------------|-------------------|----------------------|
| `Squad` | character | Team name | Standardized across datasets |
| `Pos` | character | Player position | Examples: DF, MF, FW, GK |
| `CrdY` | numeric | Yellow cards received | Count |
| `CrdR` | numeric | Red cards received | Count |
| `Season` | numeric / character | Season identifier | Matches team-season data |

------------------------------------------------------------------------

## Dataset 3: `discipline_by_position.csv`

### Description

This dataset aggregates disciplinary records by team, position group, and season.

### Unit of Observation

Each row represents one **team-position-season**.

### Variables

| Variable | Type | Description | Units / Notes |
|----------------|----------------|-------------------|----------------------|
| `Squad` | character | Team name | Standardized across datasets |
| `Pos` | character | Position group | Examples: DF, MF, FW, GK |
| `Season` | numeric / character | Season identifier | Matches team-season data |
| `count_CrdY` | numeric | Total yellow cards by position group | Count |
| `count_CrdR` | numeric | Total red cards by position group | Count |

------------------------------------------------------------------------

## Data Cleaning and Processing

The datasets were cleaned and prepared before analysis using the following steps:

-   Standardized team names across FBref and Transfermarkt datasets
-   Standardized season format across all datasets
-   Converted financial variables into numeric values
-   Aggregated player-level disciplinary data into team-position-season level
-   Merged team performance data with transfer spending, squad value, average age, and discipline data
-   Removed or handled missing values where necessary

------------------------------------------------------------------------

## Key Variables for Analysis

| Concept | Variable(s) |
|----------------------------|--------------------------------------------|
| Team performance | `Rk`, `Pts` |
| Financial investment | `spend_usd`, `income_usd`, `net_spend_usd`, `squad_value_eur` |
| Squad characteristics | `avg_age` |
| Discipline | `CrdY`, `CrdR`, `count_CrdY`, `count_CrdR` |
| Team identifier | `Squad` |
| Time identifier | `Season` |

------------------------------------------------------------------------

## Limitations

-   Transfermarkt values are market estimates, not exact transaction values
-   Some missing values may exist due to differences across data sources
-   Combining FBref and Transfermarkt data may introduce inconsistencies in team names or season formatting
-   Ranking should be interpreted carefully because a lower rank means better performance

------------------------------------------------------------------------

## Summary

These datasets allow us to analyze whether Premier League success is associated with financial investment, squad age, and disciplinary behavior. The main outcome variables are league ranking and total points, while the main explanatory variables include transfer spending, squad value, average squad age, yellow cards, and red cards.